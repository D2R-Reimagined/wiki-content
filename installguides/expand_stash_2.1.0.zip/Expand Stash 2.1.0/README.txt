This modification expands the number of available shared stash tabs from 3 to 7.

There is one folder in this .zip file

"mods"

The "mods" folder is the new SharedStashSoftcore.d2i and SharedStashHardCoreV2.d2i and nested to be droppable.

------------------------------------------------------------------------------------------------------------------------------------
TO INSTALL:
------------------------------------------------------------------------------------------------------------------------------------
===REMOVE ALL ITEMS FROM YOUR "Shared" STASH TABS ONTO MULES BEFORE INSTALLING OR THEY WILL BE LOST WHEN THE FILE IS OVERWRITTEN.===
------------------------------------------------------------------------------------------------------------------------------------
- Navigate to C:\Users\(YOU)\Saved Games folder\Diablo II Resurrected\
  - Drag the "mods" folder from the .zip into this folder (on the side, not on top of the other folder). It will ask to overwrite up to 2 files, do so, this enables more than 3 shared tabs to be able to hold items, without this they show as unavailable.