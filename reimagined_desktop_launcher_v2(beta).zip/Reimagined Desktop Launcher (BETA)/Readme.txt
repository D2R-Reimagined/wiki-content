REIMAGINED DESKTOP LAUNCHER

Contains a collection of easy to use features and modifications for Reimagined.  
	- Install/reinstall/update Reimagined
	- Launch Reimagined, and save your progress automatically
	- Install additional, pre-packaged changes

To add more launch arguments edit the relevant Play Reimagined file. Arguments must come after '-mod Reimagined -txt'.

Save Files are stored separately to mod files:

Mod Files: C:\Program Files (x86)\Diablo II Resurrected\mods\Reimagined
Save Files: C:\Users\%USERPROFILE%\Saved Games\Diablo II Resurrected\mods\Reimagined
Backup Files: C:\Users\%USERPROFILE%\Saved Games\Reimagined Automatic Saved Game Backups

--------------------------------------------------------------------------------------------------
CONTENTS:

Advanced Folder
	Contains a collection of optional changes for Reimagined.
	Double-click the relevant file to enable the desired change.
	If you update Reimagined all changes will be undone.

	For more information about each advanced tweak can be found here:
	https://wiki.d2r-reimagined.com/en/Installs

Play Reimagined (Daily Backup).bat
	Launches the game.
	Makes a copy of your Reimagined Saved Games folder with today's date.
	Backups on the same day will overwrite each other.

Play Reimagined (Session Backup).bat
	Launches the game.
	Makes a copy of your Reimagined Saved Games folder with today's date & time.
	* Note, will result in a large number of zip files over time. Delete unwanted backups as necessary.

Install Reimagined (Install-Update).bat
	Performs a fresh install of Reimagined.
	Overwrites existing compiled files.
	Any manual or advanced tweak changes will need to be redone.

--------------------------------------------------------------------------------------------------

IF THIS DID NOT WORK FOR YOU
- Make sure you unzipped the folder onto your desktop.

- Make sure you have only the latest Reimagined 7z file inside the 7zr folder.

Any other issues or suggestions, please speak to Vinge.

--------------------------------------------------------------------------------------------------

Bat files are fully transparent & editable.

This package includes the use of the 7-Zip program & this is licensed under the GNU LGPL license, where the source code can be found at www.7-zip.org.

The freeware version of 7-zip console executable was used in step 4 & doesn't install any software onto your computer, more information can be found here:
Description: 7zr.exe (x86) : 7-Zip console executable
https://www.7-zip.org/download.html